package Adapter;

import Model.Automobile;
import Model.LHMAuto;

//what is the purpose of this class???
abstract public class ProxyAutomobile {

	static protected Automobile a1;
	static protected LHMAuto<Automobile> autos;
}
