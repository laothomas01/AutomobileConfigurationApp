package Driver;

public class Lab2Driver {
	public static void main(String args[]) {

	}
}
