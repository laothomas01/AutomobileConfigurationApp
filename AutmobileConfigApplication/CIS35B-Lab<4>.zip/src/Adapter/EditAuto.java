package Adapter;

import java.io.IOException;

public interface EditAuto {

	public void editThread(String ModelName, int operation, String[] args) throws IOException;

}