package Adapter;

import Model.Automobile;
import Model.LHMAuto;

public interface ReadAuto {
	float getTotalPrice();

	void printOptionChoices();


}
