package Adapter;

public interface Debuggable {
	boolean DEBUG = true;
}
