package Driver;

import Adapter.BuildAuto;
import Adapter.CreateAuto;

import java.io.IOException;

public class Lab3Driver {
	public static void main(String args[]) throws IOException {

	}
}
